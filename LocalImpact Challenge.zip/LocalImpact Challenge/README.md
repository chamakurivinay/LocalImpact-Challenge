# 🛡️ Local Resource Directory — Safety & Community Triage Hub
> **Project #80: Local Impact Challenge | Domain: Safety & Community | Hackathon Edition**

A lightweight, resilient, and humanized Python application engineered to streamline community service discovery, validate directory records, track facility occupancy, and provide immediate operational triage insights during emergencies.

---

## 🌟 The Problem & The Impact

In community outreach, academic support, and disaster response environments, coordinators frequently experience friction when searching fragmented spreadsheets or manually parsing JSON records.

- **Without an integrated utility**, records suffer from stale contact info, calculation errors, missed surge warnings, and misplaced entries.
- **Enterprise software alternatives** demand steep learning curves, expensive recurring subscriptions, and intrusive network/cloud setups ill-suited for rapid field response.
- **Local Resource Directory** solves this by providing:
  1. **Zero-Dependency Architecture**: Runs out of the box using Python's standard library (`json`, `dataclasses`, `pathlib`, `http.server`).
  2. **Data Resilience & Safe Recovery**: Automatically isolates malformed or corrupted JSON records, keeps rolling `.bak` backups, and executes atomic file writes.
  3. **Real-time Occupancy & Surge Analytics**: Instant alerts for facilities at $\ge 85\%$ capacity or offline.
  4. **Attractive Civic Web Dashboard**: Responsive Tailwind CSS + Alpine.js UI with live search, capacity sliders, and instant status updates.
  5. **Offline Handouts & Briefings**: 1-click export to CSV for field distribution and Markdown for daily incident briefings.

---

## 📁 Project Architecture & Layout

```plaintext
LocalImpact Challenge/
├── data/
│   └── directory.json          # Persistent JSON database (auto-seeded on first run)
├── src/
│   ├── __init__.py
│   ├── models.py               # Strict schema validation, enums, & Resource dataclass
│   ├── storage.py              # Atomic writes, automatic backups (.json.bak), & corruption recovery
│   ├── engine.py               # Multi-criteria search, filtering, mutation rollback, & KPI analytics
│   ├── exporters.py            # CSV handouts, Markdown briefings, & JSON snapshots
│   ├── importer.py             # External JSON/CSV bulk ingestion with deduplication
│   ├── auditor.py              # Data hygiene, stale check (>24h), and bottleneck detection
│   ├── hours.py                # Schedule evaluator (24/7, daytime windows, overnight triage)
│   └── cli.py                  # Interactive terminal interface with ASCII tables & visual bars
├── tests/
│   ├── __init__.py
│   ├── test_models.py          # Schema validation and error handling edge cases
│   ├── test_engine.py          # Search queries, capacity filters, and mutation rollbacks
│   └── test_storage_auditor.py # Resilience under corrupted JSON, backups, and auditor rules
├── web/
│   └── index.html              # Modern, attractive civic UI (Tailwind CSS, Alpine.js, Lucide Icons)
├── app.py                      # FastAPI REST application with OpenAPI Swagger docs
├── server.py                   # Universal web server (uses FastAPI if installed, else built-in HTTP)
├── main.py                     # Unified entrypoint (CLI or --web mode)
├── requirements.txt            # Optional dependencies (fastapi, uvicorn)
└── README.md                   # Documentation and Hackathon mentor guide
```

---

## 🚀 Quick Start (Zero Friction)

### 1. Launch the Web Dashboard in Your Browser
You can run the web dashboard immediately with Python's built-in engine:

```bash
python main.py --web
```
*or directly:*
```bash
python server.py
```

Open your browser to:
👉 **[http://127.0.0.1:8000](http://127.0.0.1:8000)**

---

### 2. Launch the Interactive Terminal Interface (CLI)
For offline terminal environments or remote SSH sessions:

```bash
python main.py
```

From the terminal menu, you can:
- **1**: View all resources in a formatted table with ASCII capacity meters.
- **2**: Perform multi-criteria searches (keyword, category, status, maximum capacity, open-now).
- **3**: Inspect single facility details with contact and operating hours.
- **4**: Add new resources with instant domain validation.
- **5**: Update service status and capacity.
- **6**: View executive KPI summaries and surge alerts.
- **7**: Run data freshness and hygiene audits.
- **8**: Export CSV handouts and Markdown briefings.

---

### 3. Run Automated Quality Audits & Exports via CLI
```bash
# Run data freshness, stale record, and bottleneck check
python main.py --audit

# Generate offline CSV handouts and operational Markdown briefing
python main.py --export
```

---

## ⚡ Optional: Running with FastAPI & Uvicorn

If you have or install `fastapi` and `uvicorn`:
```bash
pip install -r requirements.txt
uvicorn app:app --reload
```
- **Web Dashboard**: [http://127.0.0.1:8000](http://127.0.0.1:8000)
- **Interactive Swagger API Docs**: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
- **Alternative ReDoc**: [http://127.0.0.1:8000/redoc](http://127.0.0.1:8000/redoc)

---

## 🎯 Hackathon Live Pitch Demo Guide

### "Show, Don't Just Tell" Resilience Demo for Judges:
1. **Show Normal Operation**: Open `http://127.0.0.1:8000` or run `python main.py`. Point out the 8 community services categorized by Healthcare, Shelter, Food Bank, etc.
2. **Deliberately Inject Corrupt Data**: Open `data/directory.json` in any text editor and insert an invalid record (e.g. set `"capacity_percent": 250` or `"category": "Unknown"` or delete `"contact"`).
3. **Observe Graceful Isolation**:
   - Refresh the web page or restart the app.
   - The application **does not crash**.
   - A bright banner appears at the top: `Data Integrity Notice: Skipped invalid entry...`.
   - All other 8 valid services remain fully searchable and functional.
4. **Demonstrate 1-Click Offline Handout Generation**: Click **Export CSV** or **Briefing** in the header. Show judges the generated `exports/daily_briefing.md` ready to be printed and handed to emergency dispatchers.

---

## 🧪 Running the Unit Tests

The test suite thoroughly verifies all validation logic, atomic writes, JSON corruption isolation, search edge cases, and auditor findings:

```bash
python -m unittest discover tests
```

Expected output:
```plaintext
Ran 20 tests in 0.074s
OK
```

---

## 📡 REST API Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/` | Serves the interactive frontend web application |
| `GET` | `/api/meta` | Returns active categories, statuses, and data integrity warnings |
| `GET` | `/api/resources` | Query resources (filters: `q`, `category`, `status`, `max_capacity`, `open_only`) |
| `GET` | `/api/resources/{id}` | Retrieve details for a single community service |
| `POST` | `/api/resources` | Register a new community service (enforces schema validation) |
| `PATCH` | `/api/resources/{id}` | Update status and/or occupancy percentage |
| `DELETE` | `/api/resources/{id}` | Remove a facility from the active directory |
| `GET` | `/api/summary` | Instant KPI analytics (average capacity, surge alerts, high availability) |
| `GET` | `/api/audit` | Data freshness and quality findings |
| `GET` | `/api/export/csv` | Download CSV formatted handout |
| `GET` | `/api/export/markdown` | Download operational briefing Markdown report |

---

## 👥 Community Impact & Sustainability
Designed with empathy for non-technical community volunteers and field coordinators:
- **No cloud vendor lock-in**
- **Zero software subscription fees**
- **Works without internet access in remote / emergency settings**
- **Audited for data hygiene and capacity bottlenecks**
