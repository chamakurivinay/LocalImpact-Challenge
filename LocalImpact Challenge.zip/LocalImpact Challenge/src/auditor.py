from dataclasses import dataclass
from datetime import datetime
from typing import List
from src.models import Resource


@dataclass
class AuditFinding:
    severity: str  # "CRITICAL", "HIGH", "MEDIUM", "LOW"
    resource_id: str
    resource_name: str
    issue: str
    recommendation: str


class DirectoryAuditor:
    """Performs comprehensive data hygiene, freshness checks, and surge risk assessments."""

    DATE_FORMAT = "%Y-%m-%d %H:%M"

    def audit(self, resources: List[Resource], stale_hours: int = 24) -> List[AuditFinding]:
        findings: List[AuditFinding] = []
        now = datetime.now()
        seen_names = {}
        seen_addresses = {}

        for r in resources:
            # 1. Capacity bottleneck & status mismatch
            if r.capacity_percent >= 90 and r.status == "Active":
                findings.append(AuditFinding(
                    severity="HIGH",
                    resource_id=r.id,
                    resource_name=r.name,
                    issue=f"Resource marked 'Active' but operating at {r.capacity_percent}% capacity.",
                    recommendation="Transition status to 'Limited' to divert incoming emergency caseload."
                ))

            if r.capacity_percent == 100 and r.status != "Closed":
                findings.append(AuditFinding(
                    severity="CRITICAL",
                    resource_id=r.id,
                    resource_name=r.name,
                    issue=f"Resource is at 100% capacity with status '{r.status}'.",
                    recommendation="Review facility queue or temporarily redirect callers."
                ))

            # 2. Stale data & timestamp verification
            try:
                updated_dt = datetime.strptime(r.last_updated, self.DATE_FORMAT)
                age_hours = (now - updated_dt).total_seconds() / 3600
                if age_hours > stale_hours:
                    findings.append(AuditFinding(
                        severity="MEDIUM",
                        resource_id=r.id,
                        resource_name=r.name,
                        issue=f"Status not verified in {int(age_hours)} hours (threshold: {stale_hours}h).",
                        recommendation="Contact community service dispatcher to confirm bed/capacity availability."
                    ))
            except ValueError:
                findings.append(AuditFinding(
                    severity="HIGH",
                    resource_id=r.id,
                    resource_name=r.name,
                    issue=f"Unparseable timestamp '{r.last_updated}'.",
                    recommendation=f"Reset timestamp to current time using standard '{self.DATE_FORMAT}' format."
                ))

            # 3. Missing search tags
            if not r.tags:
                findings.append(AuditFinding(
                    severity="LOW",
                    resource_id=r.id,
                    resource_name=r.name,
                    issue="No search tags assigned.",
                    recommendation="Add descriptive tags (e.g. 'walk-in', 'bilingual', '24/7') to improve discoverability."
                ))

            # 4. Near-duplicate facility name check
            norm_name = r.name.strip().lower()
            if norm_name in seen_names:
                prior_id = seen_names[norm_name]
                findings.append(AuditFinding(
                    severity="MEDIUM",
                    resource_id=r.id,
                    resource_name=r.name,
                    issue=f"Possible duplicate entry with ID '{prior_id}'.",
                    recommendation="Merge records or verify if these are distinct branches."
                ))
            else:
                seen_names[norm_name] = r.id

            # 5. Duplicate address check
            norm_addr = r.address.strip().lower()
            if norm_addr in seen_addresses:
                prior_id = seen_addresses[norm_addr]
                findings.append(AuditFinding(
                    severity="LOW",
                    resource_id=r.id,
                    resource_name=r.name,
                    issue=f"Shares physical address with facility '{prior_id}'.",
                    recommendation="Confirm whether co-located services need distinct suite numbers."
                ))
            else:
                seen_addresses[norm_addr] = r.name

        return findings
