import sys
import webbrowser
from typing import List, Optional
from src.engine import DirectoryEngine
from src.models import Resource, VALID_CATEGORIES, VALID_STATUSES
from src.auditor import DirectoryAuditor
from src.exporters import DirectoryExporter
from src.hours import ScheduleEvaluator


def make_capacity_bar(percent: int, length: int = 10) -> str:
    """Renders a simple visual ascii capacity bar."""
    filled = int(round((percent / 100) * length))
    filled = max(0, min(length, filled))
    bar = "█" * filled + "░" * (length - filled)
    return f"[{bar}] {percent:>3}%"


def print_table(resources: List[Resource]) -> None:
    """Renders a clean, humanized ASCII table of services."""
    if not resources:
        print("\n  [!] No matching community resources found.\n")
        return

    col_id = 9
    col_name = 32
    col_cat = 16
    col_stat = 12
    col_cap = 18
    col_hours = 12
    col_contact = 22

    header = (
        f"{'ID':<{col_id}} | "
        f"{'Service Name':<{col_name}} | "
        f"{'Category':<{col_cat}} | "
        f"{'Status':<{col_stat}} | "
        f"{'Capacity':<{col_cap}} | "
        f"{'Hours':<{col_hours}} | "
        f"{'Contact':<{col_contact}}"
    )
    separator = "-" * len(header)
    border = "=" * len(header)

    print("\n" + border)
    print(header)
    print(separator)
    for r in resources:
        cap_bar = make_capacity_bar(r.capacity_percent, length=8)
        print(
            f"{r.id:<{col_id}} | "
            f"{r.name[:col_name]:<{col_name}} | "
            f"{r.category[:col_cat]:<{col_cat}} | "
            f"{r.status[:col_stat]:<{col_stat}} | "
            f"{cap_bar:<{col_cap}} | "
            f"{r.operating_hours[:col_hours]:<{col_hours}} | "
            f"{r.contact[:col_contact]:<{col_contact}}"
        )
    print(border)
    print(f"Total shown: {len(resources)} entries\n")


def print_detail_view(res: Resource) -> None:
    """Prints a detailed view of a single resource."""
    is_open = ScheduleEvaluator.is_open_at(res.operating_hours)
    open_text = "OPEN NOW" if is_open else "CLOSED"

    print("\n" + "─" * 60)
    print(f"  Facility : {res.name} (ID: {res.id})")
    print("─" * 60)
    print(f"  Category        : {res.category}")
    print(f"  Current Status  : {res.status}")
    print(f"  Operating Hours : {res.operating_hours} [{open_text}]")
    print(f"  Capacity Level  : {make_capacity_bar(res.capacity_percent, length=12)}")
    print(f"  Address         : {res.address}")
    print(f"  Contact Info    : {res.contact}")
    print(f"  Search Tags     : {', '.join(res.tags) if res.tags else 'None'}")
    if res.description:
        print(f"  Description     : {res.description}")
    print(f"  Last Verified   : {res.last_updated}")
    print("─" * 60 + "\n")


def run_cli(engine: DirectoryEngine) -> None:
    """Main interactive terminal loop."""
    auditor = DirectoryAuditor()
    exporter = DirectoryExporter("exports")

    print("\n" + "═" * 65)
    print("      LOCAL RESOURCE DIRECTORY — SAFETY & COMMUNITY HUB")
    print("       Rapid Triage, Capacity Tracking & Community Dispatch")
    print("═" * 65)

    if engine.load_warnings:
        print("\n  [⚠️ DATA INTEGRITY NOTICES ON LOAD]")
        for w in engine.load_warnings:
            print(f"   • {w}")

    while True:
        print("\n=== MAIN MENU ===")
        print("  1. View All Community Services")
        print("  2. Search & Multi-Filter Services")
        print("  3. View Single Resource Details")
        print("  4. Add New Community Service")
        print("  5. Update Status & Capacity Level")
        print("  6. View Actionable Insights & Surge Alerts")
        print("  7. Run Data Hygiene & Freshness Audit")
        print("  8. Export Briefings (CSV & Markdown)")
        print("  9. Start Web Dashboard Server")
        print("  0. Exit")

        choice = input("\nSelect an option [0-9]: ").strip()

        if choice == "1":
            print_table(engine.resources)

        elif choice == "2":
            print("\n--- Filter Directory (press Enter to skip any criteria) ---")
            q = input("Keyword (search name, address, or tag): ").strip()

            print(f"Categories: {', '.join(sorted(VALID_CATEGORIES))}")
            cat = input("Filter by Category: ").strip() or None

            print(f"Statuses: {', '.join(sorted(VALID_STATUSES))}")
            stat = input("Filter by Status: ").strip() or None

            cap_input = input("Maximum Capacity % (e.g. 75 for space available): ").strip()
            max_cap = int(cap_input) if cap_input.isdigit() else None

            open_input = input("Only show currently open facilities? (y/n) [n]: ").strip().lower()
            open_only = open_input == "y"

            results = engine.search(
                query=q,
                category=cat,
                status=stat,
                max_capacity=max_cap,
                is_open_only=open_only
            )
            print_table(results)

        elif choice == "3":
            res_id = input("Enter Resource ID (e.g. res-001): ").strip()
            res = engine.get_resource(res_id)
            if res:
                print_detail_view(res)
            else:
                print(f"\n[!] No resource found with ID '{res_id}'.")

        elif choice == "4":
            print("\n--- Register New Community Service ---")
            try:
                name = input("Service/Facility Name*: ").strip()
                print(f"Available Categories: {', '.join(sorted(VALID_CATEGORIES))}")
                category = input("Category*: ").strip()
                address = input("Physical Address*: ").strip()
                contact = input("Contact (Phone/Email)*: ").strip()

                print(f"Statuses: {', '.join(sorted(VALID_STATUSES))}")
                status = input("Status [Active]: ").strip() or "Active"

                cap_raw = input("Current Capacity % (0-100) [0]: ").strip() or "0"
                capacity = int(cap_raw)

                hours = input("Operating Hours (e.g. '24/7' or '08:00-18:00') [24/7]: ").strip() or "24/7"
                tags_raw = input("Comma-separated tags (e.g. walk-in, hot-meals, free): ").strip()
                tags = [t.strip() for t in tags_raw.split(",") if t.strip()]
                description = input("Brief Description: ").strip()

                new_resource = Resource(
                    name=name,
                    category=category,
                    address=address,
                    contact=contact,
                    status=status,
                    capacity_percent=capacity,
                    operating_hours=hours,
                    tags=tags,
                    description=description
                )
                saved = engine.add_resource(new_resource)
                print(f"\n[+] Successfully registered '{saved.name}' with ID: {saved.id}")
            except ValueError as exc:
                print(f"\n[ERROR] Validation rejected: {exc}")

        elif choice == "5":
            res_id = input("Enter Resource ID to update: ").strip()
            res = engine.get_resource(res_id)
            if not res:
                print(f"\n[ERROR] No resource found with ID '{res_id}'.")
                continue

            print(f"Updating: '{res.name}' (Current: {res.status}, {res.capacity_percent}% cap)")
            print(f"Valid Statuses: {', '.join(sorted(VALID_STATUSES))}")
            new_status = input(f"New Status [{res.status}]: ").strip() or res.status

            cap_raw = input(f"New Capacity % (0-100) [{res.capacity_percent}]: ").strip()
            new_cap = int(cap_raw) if cap_raw.isdigit() else None

            try:
                updated = engine.update_status(res_id, new_status, new_cap)
                print(f"\n[+] Updated '{updated.name}' -> Status: {updated.status} | Capacity: {updated.capacity_percent}%")
            except (KeyError, ValueError) as exc:
                print(f"\n[ERROR] {exc}")

        elif choice == "6":
            summary = engine.generate_summary()
            if summary["total"] == 0:
                print("\nDirectory is empty.")
                continue

            print("\n" + "═" * 55)
            print("        EXECUTIVE OPERATIONAL SUMMARY")
            print("═" * 55)
            print(f"  • Total Monitored Services : {summary['total']}")
            print(f"  • Average System Capacity  : {summary['average_capacity']}%")

            print("\n  • Status Distribution:")
            for stat, count in summary["by_status"].items():
                print(f"     - {stat:<24} : {count}")

            print("\n  • Category Breakdown:")
            for cat, count in summary["by_category"].items():
                print(f"     - {cat:<24} : {count}")

            print("\n  • Critical Surge Alerts (Capacity >= 85% or Closed):")
            alerts = summary["critical_alerts"]
            if not alerts:
                print("     ✓ All facilities operating within safe operational margins.")
            else:
                for a in alerts:
                    print(f"     ⚠️ [{a.id}] {a.name} ({a.category}) -> {a.status} @ {a.capacity_percent}% capacity")

            print("\n  • High-Availability Open Resources (<= 50% cap):")
            avail = summary["high_availability"]
            if not avail:
                print("     None currently below 50% capacity.")
            else:
                for v in avail:
                    print(f"     ✓ [{v.id}] {v.name} ({v.category}) -> {v.capacity_percent}% capacity | Contact: {v.contact}")
            print("═" * 55)

        elif choice == "7":
            print("\n--- Running Data Freshness & Hygiene Audit ---")
            findings = auditor.audit(engine.resources, stale_hours=24)
            if not findings:
                print("\n✓ Perfect hygiene: No stale timestamps, duplicates, or surge mismatches found.")
            else:
                print(f"\nIdentified {len(findings)} operational advisory findings:\n")
                for f in findings:
                    severity_prefix = {
                        "CRITICAL": "[CRITICAL 🔴]",
                        "HIGH": "[HIGH 🟠]",
                        "MEDIUM": "[MEDIUM 🟡]",
                        "LOW": "[LOW 🔵]"
                    }.get(f.severity, f"[{f.severity}]")

                    print(f"  {severity_prefix} {f.resource_name} ({f.resource_id})")
                    print(f"    Issue         : {f.issue}")
                    print(f"    Recommendation: {f.recommendation}\n")

        elif choice == "8":
            print("\n--- Export Directory Handouts & Briefings ---")
            csv_file = exporter.to_csv(engine.resources, "resources_directory.csv")
            md_file = exporter.summary_to_markdown(engine.generate_summary(), "daily_briefing.md")
            json_file = exporter.to_json_snapshot(engine.resources, "snapshot.json")

            print(f"\n[+] Created CSV Handout   : {csv_file}")
            print(f"[+] Created Markdown Brief: {md_file}")
            print(f"[+] Created JSON Snapshot : {json_file}")

        elif choice == "9":
            print("\nTo start the web server, exit the CLI and run:")
            print("   python server.py")
            print("or run with flag:")
            print("   python main.py --web\n")
            open_browser = input("Would you like to start the web server now? (y/n): ").strip().lower()
            if open_browser == "y":
                from server import start_server
                start_server(port=8000)
                break

        elif choice == "0":
            print("\nExiting Local Resource Directory. Stay safe!")
            break
        else:
            print("\nInvalid choice. Please select from 0 to 9.")
