import json
import shutil
import tempfile
from pathlib import Path
from typing import List, Tuple
from src.models import Resource


class DirectoryStorage:
    """Manages resilient JSON persistence, automatic backups, and corruption recovery."""

    def __init__(self, filepath: str = "data/directory.json"):
        self.filepath = Path(filepath)
        self.filepath.parent.mkdir(parents=True, exist_ok=True)
        if not self.filepath.exists():
            self._seed_initial_data()

    def load_all(self) -> Tuple[List[Resource], List[str]]:
        """
        Loads valid resources from JSON storage.
        Isolates and logs malformed records without halting execution.
        """
        if not self.filepath.exists():
            return [], []

        try:
            content = self.filepath.read_text(encoding="utf-8")
            if not content.strip():
                return [], []
            raw_data = json.loads(content)
        except json.JSONDecodeError as exc:
            # Check if a backup file exists to rescue data
            backup_path = self.filepath.with_suffix(".json.bak")
            if backup_path.exists():
                try:
                    raw_data = json.loads(backup_path.read_text(encoding="utf-8"))
                    return self._parse_items(raw_data, [f"Primary file corrupted ({exc}). Restored from backup: {backup_path.name}"])
                except Exception:
                    pass
            raise RuntimeError(f"Critical JSON syntax error in {self.filepath}: {exc}")

        if not isinstance(raw_data, list):
            raise RuntimeError(f"Storage format error: Root JSON entity must be an array of resources.")

        return self._parse_items(raw_data)

    def _parse_items(self, raw_data: list, initial_warnings: List[str] = None) -> Tuple[List[Resource], List[str]]:
        valid_resources: List[Resource] = []
        errors: List[str] = list(initial_warnings or [])

        for idx, item in enumerate(raw_data):
            try:
                if not isinstance(item, dict):
                    raise ValueError("Item is not a valid JSON object.")
                valid_resources.append(Resource.from_dict(item))
            except (KeyError, ValueError, TypeError) as exc:
                name_hint = item.get("name", f"Record #{idx + 1}") if isinstance(item, dict) else f"Record #{idx + 1}"
                errors.append(f"Skipped invalid entry '{name_hint}': {exc}")

        return valid_resources, errors

    def save_all(self, resources: List[Resource]) -> None:
        """
        Safely serializes records with an atomic write pattern and automatic backup.
        """
        # Create rolling backup
        if self.filepath.exists():
            backup_path = self.filepath.with_suffix(".json.bak")
            try:
                shutil.copy2(self.filepath, backup_path)
            except OSError:
                pass

        serialized = [r.to_dict() for r in resources]
        json_text = json.dumps(serialized, indent=2, ensure_ascii=False)

        # Atomic file write: write to temp file first, then replace target
        temp_dir = self.filepath.parent
        with tempfile.NamedTemporaryFile("w", dir=temp_dir, delete=False, encoding="utf-8") as temp_file:
            temp_file.write(json_text)
            temp_file.flush()
            temp_path = Path(temp_file.name)

        temp_path.replace(self.filepath)

    def _seed_initial_data(self) -> None:
        """Seeds realistic community services for immediate hackathon demonstration."""
        samples = [
            Resource(
                id="res-001",
                name="Downtown Hope Community Clinic",
                category="Healthcare",
                address="402 Main Street, Suite 100",
                contact="(555) 234-8901 | clinic@downtownhope.org",
                status="Active",
                capacity_percent=45,
                operating_hours="08:00-20:00",
                tags=["walk-in", "free-consultation", "pediatrics", "bilingual"],
                description="Community health center offering no-cost triage, routine physicals, and pediatric care."
            ),
            Resource(
                id="res-002",
                name="Harbor Safe Haven Emergency Shelter",
                category="Shelter",
                address="88 Dockside Avenue",
                contact="(555) 912-3344 | triage@harborhaven.org",
                status="Limited",
                capacity_percent=92,
                operating_hours="24/7",
                tags=["24/7", "overnight-beds", "emergency", "lockers", "hot-showers"],
                description="Short-term emergency shelter with safe beds, hot showers, and case worker assistance."
            ),
            Resource(
                id="res-003",
                name="Metro Harvest Food Pantry & Kitchen",
                category="Food Bank",
                address="120 Oak Boulevard",
                contact="(555) 781-4420 | hello@metroharvest.org",
                status="Active",
                capacity_percent=35,
                operating_hours="09:00-17:00",
                tags=["hot-meals", "fresh-produce", "family-boxes", "diapers"],
                description="Nutritious grocery distribution and daily hot lunches for families and seniors."
            ),
            Resource(
                id="res-004",
                name="Civic Justice Legal Aid Coalition",
                category="Legal Aid",
                address="310 Justice Way, 4th Floor",
                contact="(555) 670-1288 | intake@civicjusticenet.org",
                status="Active",
                capacity_percent=60,
                operating_hours="09:00-16:00",
                tags=["pro-bono", "tenant-rights", "immigration", "expungement"],
                description="Pro bono legal representation defending against illegal evictions and wage theft."
            ),
            Resource(
                id="res-005",
                name="Valley Youth Crisis & Respite Sanctuary",
                category="Mental Health",
                address="514 Pine Crest Circle",
                contact="(555) 443-8822 | support@valleyyouth.org",
                status="Active",
                capacity_percent=55,
                operating_hours="24/7",
                tags=["24/7", "peer-support", "crisis-counseling", "lgbtq-safe"],
                description="Immediate crisis counseling, de-escalation support, and confidential peer groups for youth."
            ),
            Resource(
                id="res-006",
                name="Eastside Community Learning Hub",
                category="Education",
                address="772 Maplewood Lane",
                contact="(555) 890-5511 | learn@eastsidehub.org",
                status="Active",
                capacity_percent=25,
                operating_hours="10:00-19:00",
                tags=["wi-fi", "computer-lab", "adult-literacy", "after-school", "tutoring"],
                description="Public high-speed internet, job search assistance, resume workshops, and tutoring."
            ),
            Resource(
                id="res-007",
                name="North District Disaster Relief Depot",
                category="Emergency",
                address="1400 Industrial Parkway, Bay 4",
                contact="(555) 300-9911 | ops@northdistrictrelief.gov",
                status="Limited",
                capacity_percent=88,
                operating_hours="24/7",
                tags=["emergency", "clean-water", "generator-charging", "cots", "blankets"],
                description="Regional emergency distribution staging post for extreme weather and crisis mobilization."
            ),
            Resource(
                id="res-008",
                name="West End Family Resource Center",
                category="Community Center",
                address="225 Elm Street",
                contact="(555) 412-7700 | info@westendcenter.org",
                status="Active",
                capacity_percent=40,
                operating_hours="08:30-17:30",
                tags=["childcare", "elder-support", "clothing-closet", "navigator"],
                description="Neighborhood anchor providing benefits navigation, clothing closet, and family support."
            )
        ]
        self.save_all(samples)
