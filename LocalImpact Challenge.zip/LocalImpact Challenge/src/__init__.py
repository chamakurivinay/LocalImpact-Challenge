"""Local Resource Directory package."""
__version__ = "1.0.0"
