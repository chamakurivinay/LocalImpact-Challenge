import csv
import json
from datetime import datetime
from pathlib import Path
from typing import Iterable, Dict, Any
from src.models import Resource


class DirectoryExporter:
    """Exports filtered resources and briefings for physical handouts and team archives."""

    def __init__(self, output_dir: str = "exports"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def to_csv(self, resources: Iterable[Resource], filename: str = "resources_export.csv") -> Path:
        filepath = self.output_dir / filename
        fieldnames = [
            "id", "name", "category", "status",
            "capacity_percent", "operating_hours", "address", "contact",
            "tags", "description", "last_updated"
        ]

        with filepath.open("w", newline="", encoding="utf-8") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for r in resources:
                row = r.to_dict()
                row["tags"] = "; ".join(r.tags)
                writer.writerow({k: row.get(k, "") for k in fieldnames})

        return filepath

    def summary_to_markdown(self, summary: Dict[str, Any], filename: str = "daily_briefing.md") -> Path:
        filepath = self.output_dir / filename
        timestamp = summary.get("generated_at") or datetime.now().strftime("%Y-%m-%d %H:%M")

        lines = [
            "# Local Resource Directory — Operational Briefing",
            f"_Generated: {timestamp}_\n",
            "## Executive Summary",
            f"- **Total Registered Services:** {summary.get('total', 0)}",
            f"- **Average Facility Capacity:** {summary.get('average_capacity', 0)}%",
            "",
            "## Status Breakdown",
        ]

        by_status = summary.get("by_status", {})
        if by_status:
            for status, count in by_status.items():
                lines.append(f"- **{status}:** {count}")
        else:
            lines.append("- No status records available.")

        lines.append("\n## Category Distribution")
        by_category = summary.get("by_category", {})
        if by_category:
            for cat, count in by_category.items():
                lines.append(f"- **{cat}:** {count}")
        else:
            lines.append("- No category records available.")

        lines.append("\n## High Priority & Critical Alerts (Capacity >= 85% or Offline)")
        alerts = summary.get("critical_alerts", [])
        if not alerts:
            lines.append("✓ *No critical alerts. All monitored community resources within operating margins.*")
        else:
            for item in alerts:
                name = item.name if hasattr(item, "name") else item.get("name", "Unknown")
                res_id = item.id if hasattr(item, "id") else item.get("id", "N/A")
                category = item.category if hasattr(item, "category") else item.get("category", "")
                status = item.status if hasattr(item, "status") else item.get("status", "")
                capacity = item.capacity_percent if hasattr(item, "capacity_percent") else item.get("capacity_percent", 0)
                contact = item.contact if hasattr(item, "contact") else item.get("contact", "")
                address = item.address if hasattr(item, "address") else item.get("address", "")

                lines.append(
                    f"- ⚠️ **{name}** (`{res_id}`) — *{category}*\n"
                    f"  - **Status:** `{status}` | **Capacity:** `{capacity}%`\n"
                    f"  - **Location:** {address} | **Contact:** {contact}"
                )

        lines.append("\n## High-Availability Services (Immediate Referral Ready)")
        available = summary.get("high_availability", [])
        if not available:
            lines.append("- *No facilities currently under 50% capacity.*")
        else:
            for item in available:
                name = item.name if hasattr(item, "name") else item.get("name", "Unknown")
                category = item.category if hasattr(item, "category") else item.get("category", "")
                capacity = item.capacity_percent if hasattr(item, "capacity_percent") else item.get("capacity_percent", 0)
                contact = item.contact if hasattr(item, "contact") else item.get("contact", "")
                lines.append(f"- ✓ **{name}** ({category}) — `{capacity}%` capacity | {contact}")

        lines.append("\n---\n*Report compiled automatically by Local Resource Directory Engine.*")

        filepath.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return filepath

    def to_json_snapshot(self, resources: Iterable[Resource], filename: str = "snapshot.json") -> Path:
        filepath = self.output_dir / filename
        items = [r.to_dict() for r in resources]
        payload = {
            "exported_at": datetime.now().isoformat(),
            "count": len(items),
            "resources": items
        }
        filepath.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        return filepath
