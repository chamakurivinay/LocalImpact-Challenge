from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import List, Optional
import uuid

VALID_CATEGORIES = {
    "Healthcare",
    "Shelter",
    "Food Bank",
    "Legal Aid",
    "Emergency",
    "Education",
    "Mental Health",
    "Community Center"
}

VALID_STATUSES = {
    "Active",
    "Limited",
    "Closed",
    "Temporarily Unavailable"
}


@dataclass
class Resource:
    name: str
    category: str
    address: str
    contact: str
    status: str = "Active"
    capacity_percent: int = 0
    operating_hours: str = "24/7"
    tags: List[str] = field(default_factory=list)
    description: str = ""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    last_updated: str = field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M"))

    def validate(self) -> None:
        """Enforces schema integrity and domain validation rules."""
        if not self.name or not self.name.strip():
            raise ValueError("Resource name cannot be empty.")
        if self.category not in VALID_CATEGORIES:
            valid_cats = ", ".join(sorted(VALID_CATEGORIES))
            raise ValueError(f"Invalid category '{self.category}'. Must be one of: {valid_cats}")
        if self.status not in VALID_STATUSES:
            valid_stats = ", ".join(sorted(VALID_STATUSES))
            raise ValueError(f"Invalid status '{self.status}'. Must be one of: {valid_stats}")
        if not isinstance(self.capacity_percent, (int, float)) or not (0 <= int(self.capacity_percent) <= 100):
            raise ValueError("Capacity percentage must be an integer between 0 and 100.")
        if not self.contact or not self.contact.strip():
            raise ValueError("Contact information (phone or email) is required.")
        if not self.address or not self.address.strip():
            raise ValueError("Physical address or service location is required.")

    def to_dict(self) -> dict:
        """Serializes resource into a clean dictionary."""
        data = asdict(self)
        data["capacity_percent"] = int(self.capacity_percent)
        return data

    @classmethod
    def from_dict(cls, data: dict) -> "Resource":
        """Factory constructor with data normalization and strict validation."""
        tags_raw = data.get("tags", [])
        if isinstance(tags_raw, str):
            tags = [t.strip() for t in tags_raw.split(",") if t.strip()]
        elif isinstance(tags_raw, list):
            tags = [str(t).strip() for t in tags_raw if str(t).strip()]
        else:
            tags = []

        resource = cls(
            id=str(data.get("id") or str(uuid.uuid4())[:8]),
            name=str(data.get("name", "")).strip(),
            category=str(data.get("category", "")).strip(),
            address=str(data.get("address", "")).strip(),
            contact=str(data.get("contact", "")).strip(),
            status=str(data.get("status", "Active")).strip(),
            capacity_percent=int(data.get("capacity_percent", 0)),
            operating_hours=str(data.get("operating_hours", "24/7")).strip() or "24/7",
            tags=tags,
            description=str(data.get("description", "")).strip(),
            last_updated=str(data.get("last_updated") or datetime.now().strftime("%Y-%m-%d %H:%M"))
        )
        resource.validate()
        return resource
