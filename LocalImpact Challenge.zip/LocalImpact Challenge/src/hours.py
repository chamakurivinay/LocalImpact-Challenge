from datetime import datetime, time
from typing import Optional


class ScheduleEvaluator:
    """Evaluates human-readable schedule specifications against real-time clocks."""

    @staticmethod
    def is_open_at(hours_spec: str, current_time: Optional[datetime] = None) -> bool:
        """
        Determines whether a service is open based on hours string.
        Supported formats:
          - '24/7', 'always', 'open 24/7' -> True
          - 'Closed', 'None' -> False
          - 'HH:MM-HH:MM' (e.g. '08:00-18:00' or overnight '21:00-05:00')
        """
        if not hours_spec:
            return False

        spec = hours_spec.strip().lower()
        if spec in {"24/7", "always", "open 24/7", "all day"}:
            return True

        if spec in {"closed", "none", "n/a", "by appointment"}:
            return False

        if "-" not in spec:
            return False

        try:
            start_str, end_str = [part.strip() for part in spec.split("-", 1)]
            start_t = datetime.strptime(start_str, "%H:%M").time()
            end_t = datetime.strptime(end_str, "%H:%M").time()
        except ValueError:
            return False

        now_t: time = (current_time or datetime.now()).time()

        if start_t <= end_t:
            # Daytime window (e.g. 08:00 to 18:00)
            return start_t <= now_t <= end_t
        else:
            # Overnight window (e.g. 20:00 to 06:00)
            return now_t >= start_t or now_t <= end_t

    @staticmethod
    def get_status_label(hours_spec: str, current_time: Optional[datetime] = None) -> str:
        """Returns a user-friendly open/closed triage label."""
        if not hours_spec:
            return "Hours Unspecified"
        if hours_spec.strip().lower() in {"24/7", "always", "open 24/7"}:
            return "Open 24/7"
        if ScheduleEvaluator.is_open_at(hours_spec, current_time):
            return f"Open Now ({hours_spec})"
        return f"Currently Closed ({hours_spec})"
