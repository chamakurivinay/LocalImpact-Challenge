from collections import Counter
from datetime import datetime
from typing import List, Optional, Dict, Any
from src.models import Resource
from src.storage import DirectoryStorage
from src.hours import ScheduleEvaluator


class DirectoryEngine:
    """Core search, filtering, mutation, and operational analytics engine."""

    def __init__(self, storage: DirectoryStorage):
        self.storage = storage
        self.resources, self.load_warnings = self.storage.load_all()

    def reload(self) -> None:
        """Reloads records from disk storage."""
        self.resources, self.load_warnings = self.storage.load_all()

    def add_resource(self, resource: Resource) -> Resource:
        """Validates and persists a new resource entry."""
        resource.validate()
        self.resources.append(resource)
        self.storage.save_all(self.resources)
        return resource

    def get_resource(self, resource_id: str) -> Optional[Resource]:
        """Finds a single resource by its unique identifier."""
        for res in self.resources:
            if res.id == resource_id:
                return res
        return None

    def update_status(self, resource_id: str, new_status: str, new_capacity: Optional[int] = None) -> Resource:
        """Updates service status and/or capacity percentage with transactional rollback."""
        for res in self.resources:
            if res.id == resource_id:
                old_status = res.status
                old_cap = res.capacity_percent
                old_time = res.last_updated

                res.status = new_status
                if new_capacity is not None:
                    res.capacity_percent = int(new_capacity)
                res.last_updated = datetime.now().strftime("%Y-%m-%d %H:%M")

                try:
                    res.validate()
                except ValueError:
                    # Roll back on validation error
                    res.status = old_status
                    res.capacity_percent = old_cap
                    res.last_updated = old_time
                    raise

                self.storage.save_all(self.resources)
                return res
        raise KeyError(f"No community resource found with ID '{resource_id}'.")

    def update_resource(self, resource_id: str, data: Dict[str, Any]) -> Resource:
        """Full update of fields on a resource."""
        for idx, res in enumerate(self.resources):
            if res.id == resource_id:
                existing_dict = res.to_dict()
                existing_dict.update(data)
                existing_dict["id"] = resource_id
                existing_dict["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M")
                updated_res = Resource.from_dict(existing_dict)
                self.resources[idx] = updated_res
                self.storage.save_all(self.resources)
                return updated_res
        raise KeyError(f"No community resource found with ID '{resource_id}'.")

    def delete_resource(self, resource_id: str) -> bool:
        """Removes a resource from the directory."""
        initial_len = len(self.resources)
        self.resources = [r for r in self.resources if r.id != resource_id]
        if len(self.resources) < initial_len:
            self.storage.save_all(self.resources)
            return True
        return False

    def search(
        self,
        query: str = "",
        category: Optional[str] = None,
        status: Optional[str] = None,
        max_capacity: Optional[int] = None,
        is_open_only: bool = False,
    ) -> List[Resource]:
        """Multi-criteria search supporting keyword, category, status, capacity ceiling, and open hours."""
        results = list(self.resources)
        q = query.strip().lower()

        if q:
            results = [
                r for r in results
                if q in r.name.lower()
                or q in r.address.lower()
                or q in r.description.lower()
                or any(q in tag.lower() for tag in r.tags)
            ]

        if category:
            cat_lower = category.strip().lower()
            results = [r for r in results if r.category.lower() == cat_lower]

        if status:
            stat_lower = status.strip().lower()
            results = [r for r in results if r.status.lower() == stat_lower]

        if max_capacity is not None:
            results = [r for r in results if r.capacity_percent <= max_capacity]

        if is_open_only:
            results = [r for r in results if ScheduleEvaluator.is_open_at(r.operating_hours)]

        return results

    def generate_summary(self) -> Dict[str, Any]:
        """Produces instantaneous executive KPI metrics and surge alerts."""
        total = len(self.resources)
        if total == 0:
            return {
                "total": 0,
                "by_status": {},
                "by_category": {},
                "average_capacity": 0.0,
                "critical_alerts": [],
                "high_availability": [],
                "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }

        status_counts = Counter(r.status for r in self.resources)
        category_counts = Counter(r.category for r in self.resources)
        avg_capacity = round(sum(r.capacity_percent for r in self.resources) / total, 1)

        critical_alerts = [
            r for r in self.resources
            if r.capacity_percent >= 85 or r.status in {"Closed", "Temporarily Unavailable"}
        ]

        high_availability = [
            r for r in self.resources
            if r.status == "Active" and r.capacity_percent <= 50
        ]

        return {
            "total": total,
            "by_status": dict(status_counts),
            "by_category": dict(category_counts),
            "average_capacity": avg_capacity,
            "critical_alerts": critical_alerts,
            "high_availability": high_availability,
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
