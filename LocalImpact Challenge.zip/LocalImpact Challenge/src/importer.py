import csv
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Union
from src.models import Resource


@dataclass
class ImportReport:
    added: int = 0
    updated: int = 0
    skipped: int = 0
    errors: List[str] = field(default_factory=list)


class DirectoryImporter:
    """Safely ingests external feeds, dedupes against existing records, and isolates errors."""

    @staticmethod
    def _normalize_key(name: str, address: str) -> str:
        return f"{name.strip().lower()}::{address.strip().lower()}"

    def import_from_json(
        self,
        filepath: Union[str, Path],
        existing_resources: List[Resource],
        upsert_by_name_address: bool = True
    ) -> ImportReport:
        report = ImportReport()
        path = Path(filepath)

        if not path.exists():
            report.errors.append(f"File not found: {path}")
            return report

        try:
            raw_items = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            report.errors.append(f"Failed to parse JSON '{path}': {exc}")
            return report

        if not isinstance(raw_items, list):
            report.errors.append("JSON root must be an array of resource objects.")
            return report

        index_by_key = {
            self._normalize_key(r.name, r.address): r
            for r in existing_resources
        }

        for idx, entry in enumerate(raw_items, start=1):
            try:
                candidate = Resource.from_dict(entry)
                key = self._normalize_key(candidate.name, candidate.address)

                if upsert_by_name_address and key in index_by_key:
                    target = index_by_key[key]
                    target.category = candidate.category
                    target.contact = candidate.contact
                    target.status = candidate.status
                    target.capacity_percent = candidate.capacity_percent
                    target.operating_hours = candidate.operating_hours
                    target.tags = candidate.tags
                    target.description = candidate.description
                    target.last_updated = candidate.last_updated
                    report.updated += 1
                else:
                    existing_resources.append(candidate)
                    index_by_key[key] = candidate
                    report.added += 1
            except Exception as exc:
                report.skipped += 1
                name_hint = entry.get("name", f"Row #{idx}") if isinstance(entry, dict) else f"Row #{idx}"
                report.errors.append(f"Entry '{name_hint}' rejected: {exc}")

        return report

    def import_from_csv(
        self,
        filepath: Union[str, Path],
        existing_resources: List[Resource],
        upsert_by_name_address: bool = True
    ) -> ImportReport:
        report = ImportReport()
        path = Path(filepath)

        if not path.exists():
            report.errors.append(f"File not found: {path}")
            return report

        try:
            with path.open("r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                converted = []
                for row in reader:
                    raw_tags = row.get("tags", "")
                    tags = [t.strip() for t in raw_tags.split(";") if t.strip()]
                    converted.append({
                        "name": row.get("name", ""),
                        "category": row.get("category", ""),
                        "address": row.get("address", ""),
                        "contact": row.get("contact", ""),
                        "status": row.get("status") or "Active",
                        "capacity_percent": int(row.get("capacity_percent") or 0),
                        "operating_hours": row.get("operating_hours") or "24/7",
                        "tags": tags,
                        "description": row.get("description", ""),
                    })
        except Exception as exc:
            report.errors.append(f"Failed to read CSV '{path}': {exc}")
            return report

        index_by_key = {
            self._normalize_key(r.name, r.address): r
            for r in existing_resources
        }

        for idx, item in enumerate(converted, start=1):
            try:
                candidate = Resource.from_dict(item)
                key = self._normalize_key(candidate.name, candidate.address)
                if upsert_by_name_address and key in index_by_key:
                    target = index_by_key[key]
                    target.category = candidate.category
                    target.status = candidate.status
                    target.capacity_percent = candidate.capacity_percent
                    target.operating_hours = candidate.operating_hours
                    target.contact = candidate.contact
                    target.tags = candidate.tags
                    target.description = candidate.description
                    target.last_updated = candidate.last_updated
                    report.updated += 1
                else:
                    existing_resources.append(candidate)
                    index_by_key[key] = candidate
                    report.added += 1
            except Exception as exc:
                report.skipped += 1
                report.errors.append(f"CSV row #{idx} ({item.get('name')}) rejected: {exc}")

        return report
