# Local Resource Directory — Operational Briefing
_Generated: 2026-11-22 13:01:32_

## Executive Summary
- **Total Registered Services:** 8
- **Average Facility Capacity:** 55.0%

## Status Breakdown
- **Active:** 6
- **Limited:** 2

## Category Distribution
- **Healthcare:** 1
- **Shelter:** 1
- **Food Bank:** 1
- **Legal Aid:** 1
- **Mental Health:** 1
- **Education:** 1
- **Emergency:** 1
- **Community Center:** 1

## High Priority & Critical Alerts (Capacity >= 85% or Offline)
- ⚠️ **Harbor Safe Haven Emergency Shelter** (`res-002`) — *Shelter*
  - **Status:** `Limited` | **Capacity:** `92%`
  - **Location:** 88 Dockside Avenue | **Contact:** (555) 912-3344 | triage@harborhaven.org
- ⚠️ **North District Disaster Relief Depot** (`res-007`) — *Emergency*
  - **Status:** `Limited` | **Capacity:** `88%`
  - **Location:** 1400 Industrial Parkway, Bay 4 | **Contact:** (555) 300-9911 | ops@northdistrictrelief.gov

## High-Availability Services (Immediate Referral Ready)
- ✓ **Downtown Hope Community Clinic** (Healthcare) — `45%` capacity | (555) 234-8901 | clinic@downtownhope.org
- ✓ **Metro Harvest Food Pantry & Kitchen** (Food Bank) — `35%` capacity | (555) 781-4420 | hello@metroharvest.org
- ✓ **Eastside Community Learning Hub** (Education) — `25%` capacity | (555) 890-5511 | learn@eastsidehub.org
- ✓ **West End Family Resource Center** (Community Center) — `40%` capacity | (555) 412-7700 | info@westendcenter.org

---
*Report compiled automatically by Local Resource Directory Engine.*
