from pathlib import Path
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Query, Response
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel, Field

from src.storage import DirectoryStorage
from src.engine import DirectoryEngine
from src.models import Resource, VALID_CATEGORIES, VALID_STATUSES
from src.auditor import DirectoryAuditor
from src.exporters import DirectoryExporter

app = FastAPI(
    title="Local Resource Directory API",
    description="Safety & Community Services Rapid Triage, Capacity Tracking and Dispatch API.",
    version="1.0.0"
)

storage = DirectoryStorage("data/directory.json")
engine = DirectoryEngine(storage)
auditor = DirectoryAuditor()
exporter = DirectoryExporter("exports")


class ResourceCreate(BaseModel):
    name: str = Field(..., min_length=1, description="Official facility or service name")
    category: str = Field(..., description="Service classification category")
    address: str = Field(..., min_length=1, description="Physical address or dispatch location")
    contact: str = Field(..., min_length=1, description="Phone number or emergency email")
    status: str = Field("Active", description="Current operating status")
    capacity_percent: int = Field(0, ge=0, le=100, description="Occupancy percentage (0-100)")
    operating_hours: str = Field("24/7", description="Hours format: 24/7 or HH:MM-HH:MM")
    tags: List[str] = Field(default_factory=list, description="Keywords for instant search")
    description: str = Field("", description="Optional program details or intake guidelines")


class ResourceUpdate(BaseModel):
    status: Optional[str] = Field(None, description="Updated operating status")
    capacity_percent: Optional[int] = Field(None, ge=0, le=100, description="Updated capacity level")


@app.get("/", response_class=HTMLResponse)
def serve_frontend():
    """Serves the interactive civic frontend dashboard."""
    html_path = Path("web/index.html")
    if not html_path.exists():
        raise HTTPException(status_code=404, detail="web/index.html not found.")
    return html_path.read_text(encoding="utf-8")


@app.get("/api/meta")
def get_metadata():
    """Returns application classification domains and storage warnings."""
    return {
        "categories": sorted(VALID_CATEGORIES),
        "statuses": sorted(VALID_STATUSES),
        "warnings": engine.load_warnings,
    }


@app.get("/api/resources")
def list_resources(
    q: str = Query("", description="Keyword search in name, address, description, or tags"),
    category: Optional[str] = Query(None, description="Filter by category"),
    status: Optional[str] = Query(None, description="Filter by status"),
    max_capacity: Optional[int] = Query(None, description="Filter by maximum capacity percentage"),
    open_only: bool = Query(False, description="Filter to only open services")
):
    """Retrieves directory resources with multi-criteria filtering."""
    results = engine.search(
        query=q,
        category=category or None,
        status=status or None,
        max_capacity=max_capacity,
        is_open_only=open_only
    )
    return [r.to_dict() for r in results]


@app.get("/api/resources/{resource_id}")
def get_single_resource(resource_id: str):
    """Retrieves a single resource by its unique ID."""
    res = engine.get_resource(resource_id)
    if not res:
        raise HTTPException(status_code=404, detail=f"Resource '{resource_id}' not found.")
    return res.to_dict()


@app.post("/api/resources", status_code=201)
def create_resource(payload: ResourceCreate):
    """Registers and persists a new community service."""
    try:
        new_resource = Resource(
            name=payload.name,
            category=payload.category,
            address=payload.address,
            contact=payload.contact,
            status=payload.status,
            capacity_percent=payload.capacity_percent,
            operating_hours=payload.operating_hours,
            tags=payload.tags,
            description=payload.description
        )
        created = engine.add_resource(new_resource)
        return created.to_dict()
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.patch("/api/resources/{resource_id}")
def update_resource(resource_id: str, payload: ResourceUpdate):
    """Updates the status or capacity of an existing resource."""
    res = engine.get_resource(resource_id)
    if not res:
        raise HTTPException(status_code=404, detail=f"Resource '{resource_id}' not found.")

    target_status = payload.status if payload.status is not None else res.status
    target_capacity = payload.capacity_percent if payload.capacity_percent is not None else res.capacity_percent

    try:
        updated = engine.update_status(
            resource_id=resource_id,
            new_status=target_status,
            new_capacity=target_capacity,
        )
        return updated.to_dict()
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.delete("/api/resources/{resource_id}")
def delete_resource(resource_id: str):
    """Removes a resource from the directory."""
    success = engine.delete_resource(resource_id)
    if not success:
        raise HTTPException(status_code=404, detail=f"Resource '{resource_id}' not found.")
    return {"deleted": True, "id": resource_id}


@app.get("/api/summary")
def get_summary():
    """Returns KPI summary metrics, capacity load, and critical surge alerts."""
    summary = engine.generate_summary()
    if "critical_alerts" in summary:
        summary["critical_alerts"] = [r.to_dict() for r in summary["critical_alerts"]]
    if "high_availability" in summary:
        summary["high_availability"] = [r.to_dict() for r in summary["high_availability"]]
    return summary


@app.get("/api/audit")
def get_audit_findings():
    """Performs data quality and freshness auditing."""
    findings = auditor.audit(engine.resources, stale_hours=24)
    return [
        {
            "severity": f.severity,
            "resource_id": f.resource_id,
            "resource_name": f.resource_name,
            "issue": f.issue,
            "recommendation": f.recommendation,
        }
        for f in findings
    ]


@app.get("/api/export/csv")
def export_csv():
    """Generates and serves a downloadable CSV export."""
    csv_path = exporter.to_csv(engine.resources, "resources_directory.csv")
    return FileResponse(
        path=str(csv_path),
        media_type="text/csv",
        filename="local_community_resources.csv"
    )


@app.get("/api/export/markdown")
def export_markdown():
    """Generates and serves the operational briefing Markdown document."""
    summary = engine.generate_summary()
    md_path = exporter.summary_to_markdown(summary, "daily_briefing.md")
    return FileResponse(
        path=str(md_path),
        media_type="text/markdown",
        filename="daily_briefing.md"
    )
