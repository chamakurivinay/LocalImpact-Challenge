import argparse
import sys
from src.storage import DirectoryStorage
from src.engine import DirectoryEngine
from src.cli import run_cli
from src.exporters import DirectoryExporter
from src.auditor import DirectoryAuditor


def main():
    parser = argparse.ArgumentParser(
        description="Local Resource Directory — Safety & Community Services Triage Application",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py             # Launch the interactive terminal CLI
  python main.py --web       # Launch the local web server and open in browser
  python main.py --audit     # Check data freshness and capacity surge bottlenecks
  python main.py --export    # Export CSV handouts and Markdown operational briefing
        """
    )
    parser.add_argument("--web", "--server", action="store_true", help="Launch the local web dashboard server")
    parser.add_argument("--port", type=int, default=8000, help="Port to bind web server (default: 8000)")
    parser.add_argument("--host", type=str, default="127.0.0.1", help="Host interface (default: 127.0.0.1)")
    parser.add_argument("--audit", action="store_true", help="Run data hygiene & freshness check")
    parser.add_argument("--export", action="store_true", help="Generate CSV and Markdown briefing reports")

    args = parser.parse_args()

    storage = DirectoryStorage("data/directory.json")
    engine = DirectoryEngine(storage)

    if args.web:
        from server import start_server
        start_server(host=args.host, port=args.port)
        return

    if args.audit:
        auditor = DirectoryAuditor()
        findings = auditor.audit(engine.resources, stale_hours=24)
        print(f"\n--- DATA QUALITY & HYGIENE AUDIT ({len(findings)} findings) ---")
        if not findings:
            print("✓ All records are verified, tagged, and operating within normal capacity limits.")
        for f in findings:
            print(f"[{f.severity}] {f.resource_name} ({f.resource_id}) -> {f.issue}")
            print(f"   Recommendation: {f.recommendation}")
        return

    if args.export:
        exporter = DirectoryExporter("exports")
        csv_p = exporter.to_csv(engine.resources, "resources_directory.csv")
        md_p = exporter.summary_to_markdown(engine.generate_summary(), "daily_briefing.md")
        json_p = exporter.to_json_snapshot(engine.resources, "snapshot.json")
        print(f"\n[+] Generated CSV Handout   : {csv_p}")
        print(f"[+] Generated Markdown Brief: {md_p}")
        print(f"[+] Generated JSON Snapshot : {json_p}")
        return

    # Default to interactive CLI
    run_cli(engine)


if __name__ == "__main__":
    main()
