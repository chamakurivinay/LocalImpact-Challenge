"""Unit test package for Local Resource Directory."""
