import unittest
import tempfile
import shutil
from pathlib import Path

from src.models import Resource
from src.storage import DirectoryStorage
from src.engine import DirectoryEngine


class TestDirectoryEngine(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.file_path = Path(self.test_dir) / "test_directory.json"
        self.storage = DirectoryStorage(str(self.file_path))
        self.engine = DirectoryEngine(self.storage)

    def tearDown(self):
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_initial_seeding(self):
        self.assertGreater(len(self.engine.resources), 0)

    def test_add_resource(self):
        initial_count = len(self.engine.resources)
        new_res = Resource(
            name="New Hope Clinic",
            category="Healthcare",
            address="99 Care St",
            contact="555-1122",
            status="Active",
            capacity_percent=20
        )
        created = self.engine.add_resource(new_res)
        self.assertEqual(len(self.engine.resources), initial_count + 1)
        self.assertIsNotNone(created.id)

        # Check persistence
        reloaded_engine = DirectoryEngine(self.storage)
        found = reloaded_engine.get_resource(created.id)
        self.assertIsNotNone(found)
        self.assertEqual(found.name, "New Hope Clinic")

    def test_search_by_keyword(self):
        results = self.engine.search(query="clinic")
        for r in results:
            match = "clinic" in r.name.lower() or "clinic" in r.address.lower() or any("clinic" in t.lower() for t in r.tags)
            self.assertTrue(match)

    def test_search_by_category_and_status(self):
        results = self.engine.search(category="Healthcare", status="Active")
        for r in results:
            self.assertEqual(r.category.lower(), "healthcare")
            self.assertEqual(r.status.lower(), "active")

    def test_search_max_capacity(self):
        results = self.engine.search(max_capacity=50)
        for r in results:
            self.assertLessEqual(r.capacity_percent, 50)

    def test_update_status_and_capacity(self):
        res = self.engine.resources[0]
        res_id = res.id
        updated = self.engine.update_status(res_id, new_status="Limited", new_capacity=95)
        self.assertEqual(updated.status, "Limited")
        self.assertEqual(updated.capacity_percent, 95)

    def test_update_status_rollback_on_invalid(self):
        res = self.engine.resources[0]
        res_id = res.id
        old_status = res.status
        old_cap = res.capacity_percent

        with self.assertRaises(ValueError):
            self.engine.update_status(res_id, new_status="InvalidStatusName")

        # Verify rollback
        current = self.engine.get_resource(res_id)
        self.assertEqual(current.status, old_status)
        self.assertEqual(current.capacity_percent, old_cap)

    def test_delete_resource(self):
        res = self.engine.resources[0]
        res_id = res.id
        initial_len = len(self.engine.resources)
        success = self.engine.delete_resource(res_id)
        self.assertTrue(success)
        self.assertEqual(len(self.engine.resources), initial_len - 1)
        self.assertIsNone(self.engine.get_resource(res_id))

    def test_summary_generation(self):
        summary = self.engine.generate_summary()
        self.assertIn("total", summary)
        self.assertIn("by_status", summary)
        self.assertIn("by_category", summary)
        self.assertIn("average_capacity", summary)
        self.assertIn("critical_alerts", summary)
        self.assertEqual(summary["total"], len(self.engine.resources))


if __name__ == "__main__":
    unittest.main()
