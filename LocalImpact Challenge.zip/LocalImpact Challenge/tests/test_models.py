import unittest
from src.models import Resource, VALID_CATEGORIES, VALID_STATUSES


class TestResourceModel(unittest.TestCase):
    def test_valid_resource_creation(self):
        res = Resource(
            name="Downtown Health Oasis",
            category="Healthcare",
            address="123 Care Lane",
            contact="555-0100",
            status="Active",
            capacity_percent=50
        )
        res.validate()
        self.assertEqual(res.name, "Downtown Health Oasis")
        self.assertEqual(res.capacity_percent, 50)
        self.assertEqual(res.status, "Active")

    def test_empty_name_raises(self):
        res = Resource(
            name="   ",
            category="Healthcare",
            address="123 Care Lane",
            contact="555-0100"
        )
        with self.assertRaises(ValueError):
            res.validate()

    def test_invalid_category_raises(self):
        res = Resource(
            name="Test Center",
            category="Astronomy",  # Not in valid categories
            address="123 Care Lane",
            contact="555-0100"
        )
        with self.assertRaises(ValueError) as ctx:
            res.validate()
        self.assertIn("Invalid category", str(ctx.exception))

    def test_invalid_status_raises(self):
        res = Resource(
            name="Test Center",
            category="Shelter",
            address="123 Care Lane",
            contact="555-0100",
            status="UnknownStatus"
        )
        with self.assertRaises(ValueError) as ctx:
            res.validate()
        self.assertIn("Invalid status", str(ctx.exception))

    def test_capacity_percent_out_of_bounds(self):
        with self.assertRaises(ValueError):
            Resource(
                name="Test Center",
                category="Shelter",
                address="123 Care Lane",
                contact="555-0100",
                capacity_percent=150
            ).validate()

        with self.assertRaises(ValueError):
            Resource(
                name="Test Center",
                category="Shelter",
                address="123 Care Lane",
                contact="555-0100",
                capacity_percent=-5
            ).validate()

    def test_missing_contact_raises(self):
        with self.assertRaises(ValueError):
            Resource(
                name="Test Center",
                category="Food Bank",
                address="123 Care Lane",
                contact=""
            ).validate()

    def test_serialization_roundtrip(self):
        orig = Resource(
            name="Metro Oasis",
            category="Healthcare",
            address="402 Main St",
            contact="555-9988",
            status="Limited",
            capacity_percent=85,
            tags=["walk-in", "free"],
            description="Triage support"
        )
        orig.validate()
        data = orig.to_dict()
        reconstituted = Resource.from_dict(data)
        self.assertEqual(orig.id, reconstituted.id)
        self.assertEqual(orig.name, reconstituted.name)
        self.assertEqual(orig.tags, reconstituted.tags)


if __name__ == "__main__":
    unittest.main()
