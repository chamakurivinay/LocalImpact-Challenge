import unittest
import tempfile
import shutil
import json
from pathlib import Path
from datetime import datetime, timedelta

from src.models import Resource
from src.storage import DirectoryStorage
from src.auditor import DirectoryAuditor
from src.hours import ScheduleEvaluator
from src.exporters import DirectoryExporter


class TestStorageAndAuditor(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.file_path = Path(self.test_dir) / "corruptible.json"

    def tearDown(self):
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_corrupted_records_isolated_without_crash(self):
        # Create a JSON with 2 valid records and 2 invalid records
        data = [
            {
                "name": "Valid Center One",
                "category": "Healthcare",
                "address": "123 Main St",
                "contact": "555-0101",
                "status": "Active",
                "capacity_percent": 30
            },
            {
                "name": "Corrupted Entry 1",
                "category": "Healthcare",
                "address": "123 Main St",
                "contact": "555-0102",
                "capacity_percent": 150  # INVALID CAPACITY > 100
            },
            {
                "name": "Valid Center Two",
                "category": "Food Bank",
                "address": "456 Oak St",
                "contact": "555-0103",
                "status": "Active",
                "capacity_percent": 50
            },
            {
                "name": "Corrupted Entry 2",
                "category": "InvalidCategory123",  # INVALID CATEGORY
                "address": "789 Pine St",
                "contact": "555-0104"
            }
        ]
        self.file_path.write_text(json.dumps(data), encoding="utf-8")

        storage = DirectoryStorage(str(self.file_path))
        resources, warnings = storage.load_all()

        # Both valid records should load successfully
        self.assertEqual(len(resources), 2)
        # Both corrupted records should be collected in warnings
        self.assertEqual(len(warnings), 2)
        self.assertIn("Corrupted Entry 1", warnings[0])
        self.assertIn("Corrupted Entry 2", warnings[1])

    def test_auditor_flags_stale_and_high_capacity(self):
        stale_time = (datetime.now() - timedelta(hours=48)).strftime("%Y-%m-%d %H:%M")
        resources = [
            Resource(
                id="r1",
                name="Crowded Shelter",
                category="Shelter",
                address="100 Harbor Rd",
                contact="555-9090",
                status="Active",  # Active but 95% capacity
                capacity_percent=95,
                tags=["shelter"],
                last_updated=datetime.now().strftime("%Y-%m-%d %H:%M")
            ),
            Resource(
                id="r2",
                name="Stale Health Station",
                category="Healthcare",
                address="200 Health Way",
                contact="555-9091",
                status="Active",
                capacity_percent=40,
                tags=[],  # Missing tags
                last_updated=stale_time  # Stale timestamp
            ),
            Resource(
                id="r3",
                name="Crowded Shelter",  # Duplicate name
                category="Shelter",
                address="100 Harbor Rd",
                contact="555-9090",
                status="Limited",
                capacity_percent=95,
                tags=["shelter"]
            )
        ]

        auditor = DirectoryAuditor()
        findings = auditor.audit(resources, stale_hours=24)
        issues_text = " ".join(f.issue for f in findings)

        self.assertIn("operating at 95% capacity", issues_text)
        self.assertIn("not verified in", issues_text)
        self.assertIn("No search tags assigned", issues_text)
        self.assertIn("duplicate", issues_text.lower())

    def test_schedule_evaluator(self):
        self.assertTrue(ScheduleEvaluator.is_open_at("24/7"))
        self.assertTrue(ScheduleEvaluator.is_open_at("Open 24/7"))
        self.assertFalse(ScheduleEvaluator.is_open_at("Closed"))

        # Test specific time windows
        morning = datetime(2026, 1, 1, 10, 0)  # 10:00 AM
        self.assertTrue(ScheduleEvaluator.is_open_at("08:00-18:00", current_time=morning))

        night = datetime(2026, 1, 1, 23, 0)  # 11:00 PM
        self.assertFalse(ScheduleEvaluator.is_open_at("08:00-18:00", current_time=night))
        # Overnight window 21:00-06:00 open at 23:00
        self.assertTrue(ScheduleEvaluator.is_open_at("21:00-06:00", current_time=night))

    def test_exporters(self):
        exporter = DirectoryExporter(output_dir=self.test_dir)
        resources = [
            Resource(
                id="test-1",
                name="Test Pantry",
                category="Food Bank",
                address="100 Elm St",
                contact="555-1234",
                capacity_percent=25,
                tags=["food", "fresh"]
            )
        ]
        csv_path = exporter.to_csv(resources, "test_export.csv")
        self.assertTrue(csv_path.exists())
        self.assertIn("Test Pantry", csv_path.read_text(encoding="utf-8"))

        summary = {
            "total": 1,
            "average_capacity": 25.0,
            "by_status": {"Active": 1},
            "by_category": {"Food Bank": 1},
            "critical_alerts": [],
            "high_availability": resources
        }
        md_path = exporter.summary_to_markdown(summary, "test_briefing.md")
        self.assertTrue(md_path.exists())
        self.assertIn("Operational Briefing", md_path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
