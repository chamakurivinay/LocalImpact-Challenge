import json
import os
import sys
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Optional

from src.storage import DirectoryStorage
from src.engine import DirectoryEngine
from src.models import Resource, VALID_CATEGORIES, VALID_STATUSES
from src.auditor import DirectoryAuditor
from src.exporters import DirectoryExporter

storage = DirectoryStorage("data/directory.json")
engine = DirectoryEngine(storage)
auditor = DirectoryAuditor()
exporter = DirectoryExporter("exports")


class StandaloneDirectoryHandler(BaseHTTPRequestHandler):
    """
    Standard-library HTTP request handler implementing the complete REST API.
    Guarantees 100% offline, zero-dependency execution for hackathons and demos.
    """

    def send_json(self, status_code: int, data: object):
        payload = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(payload)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        # 1. Frontend Homepage
        if path == "/" or path == "/index.html":
            html_file = Path("web/index.html")
            if not html_file.exists():
                self.send_error(404, "web/index.html not found.")
                return
            content = html_file.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
            return

        # 2. Metadata
        if path == "/api/meta":
            self.send_json(200, {
                "categories": sorted(VALID_CATEGORIES),
                "statuses": sorted(VALID_STATUSES),
                "warnings": engine.load_warnings
            })
            return

        # 3. Resources List & Search
        if path == "/api/resources":
            q = query.get("q", [""])[0]
            cat = query.get("category", [None])[0]
            stat = query.get("status", [None])[0]
            max_cap_str = query.get("max_capacity", [None])[0]
            max_cap = int(max_cap_str) if max_cap_str and max_cap_str.isdigit() else None
            open_only = query.get("open_only", ["false"])[0].lower() in {"true", "1", "yes"}

            results = engine.search(
                query=q,
                category=cat,
                status=stat,
                max_capacity=max_cap,
                is_open_only=open_only
            )
            self.send_json(200, [r.to_dict() for r in results])
            return

        # 4. Summary & KPIs
        if path == "/api/summary":
            summary = engine.generate_summary()
            if "critical_alerts" in summary:
                summary["critical_alerts"] = [r.to_dict() for r in summary["critical_alerts"]]
            if "high_availability" in summary:
                summary["high_availability"] = [r.to_dict() for r in summary["high_availability"]]
            self.send_json(200, summary)
            return

        # 5. Data Quality Audit
        if path == "/api/audit":
            findings = auditor.audit(engine.resources, stale_hours=24)
            data = [
                {
                    "severity": f.severity,
                    "resource_id": f.resource_id,
                    "resource_name": f.resource_name,
                    "issue": f.issue,
                    "recommendation": f.recommendation
                }
                for f in findings
            ]
            self.send_json(200, data)
            return

        # 6. CSV Export Download
        if path == "/api/export/csv":
            csv_path = exporter.to_csv(engine.resources, "resources_directory.csv")
            content = csv_path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/csv; charset=utf-8")
            self.send_header("Content-Disposition", 'attachment; filename="local_community_resources.csv"')
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
            return

        # 7. Markdown Briefing Download
        if path == "/api/export/markdown":
            summary = engine.generate_summary()
            md_path = exporter.summary_to_markdown(summary, "daily_briefing.md")
            content = md_path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/markdown; charset=utf-8")
            self.send_header("Content-Disposition", 'attachment; filename="daily_briefing.md"')
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
            return

        # 8. Single Resource GET: /api/resources/{id}
        if path.startswith("/api/resources/"):
            res_id = path[len("/api/resources/"):]
            res = engine.get_resource(res_id)
            if res:
                self.send_json(200, res.to_dict())
            else:
                self.send_json(404, {"detail": f"Resource '{res_id}' not found."})
            return

        self.send_error(404, "Path not found.")

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/api/resources":
            content_len = int(self.headers.get("Content-Length", 0))
            raw_body = self.rfile.read(content_len).decode("utf-8")
            try:
                body = json.loads(raw_body)
                new_resource = Resource(
                    name=body.get("name", ""),
                    category=body.get("category", ""),
                    address=body.get("address", ""),
                    contact=body.get("contact", ""),
                    status=body.get("status", "Active"),
                    capacity_percent=int(body.get("capacity_percent", 0)),
                    operating_hours=body.get("operating_hours", "24/7"),
                    tags=body.get("tags", []),
                    description=body.get("description", "")
                )
                created = engine.add_resource(new_resource)
                self.send_json(201, created.to_dict())
            except ValueError as exc:
                self.send_json(400, {"detail": str(exc)})
            except Exception as exc:
                self.send_json(500, {"detail": f"Internal error: {exc}"})
            return

        self.send_error(404, "Endpoint not found.")

    def do_PATCH(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path.startswith("/api/resources/"):
            res_id = path[len("/api/resources/"):]
            content_len = int(self.headers.get("Content-Length", 0))
            raw_body = self.rfile.read(content_len).decode("utf-8")
            try:
                body = json.loads(raw_body)
                new_status = body.get("status")
                new_capacity = body.get("capacity_percent")
                if new_capacity is not None:
                    new_capacity = int(new_capacity)

                res = engine.get_resource(res_id)
                if not res:
                    self.send_json(404, {"detail": f"Resource '{res_id}' not found."})
                    return

                target_status = new_status if new_status is not None else res.status
                target_capacity = new_capacity if new_capacity is not None else res.capacity_percent

                updated = engine.update_status(res_id, target_status, target_capacity)
                self.send_json(200, updated.to_dict())
            except KeyError as exc:
                self.send_json(404, {"detail": str(exc)})
            except ValueError as exc:
                self.send_json(400, {"detail": str(exc)})
            except Exception as exc:
                self.send_json(500, {"detail": f"Internal error: {exc}"})
            return

        self.send_error(404, "Endpoint not found.")

    def do_DELETE(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path.startswith("/api/resources/"):
            res_id = path[len("/api/resources/"):]
            deleted = engine.delete_resource(res_id)
            if deleted:
                self.send_json(200, {"deleted": True, "id": res_id})
            else:
                self.send_json(404, {"detail": f"Resource '{res_id}' not found."})
            return

        self.send_error(404, "Endpoint not found.")

    def log_message(self, format, *args):
        # Clean logging format
        sys.stderr.write(f"[{self.log_date_time_string()}] {self.command} {args[0]} -> {args[1]}\n")


def start_server(host: str = "127.0.0.1", port: int = 8000):
    """
    Launches server. Automatically prefers FastAPI/uvicorn if installed,
    falling back seamlessly to built-in HTTP server for guaranteed zero-dependency running.
    """
    try:
        import uvicorn
        print("⚡ FastAPI & Uvicorn detected. Launching asynchronous production engine...", flush=True)
        uvicorn.run("app:app", host=host, port=port, reload=True)
        return
    except ImportError:
        pass

    print("\n" + "=" * 65, flush=True)
    print("  🚀 LOCAL RESOURCE DIRECTORY — ZERO-DEPENDENCY SERVER", flush=True)
    print("=" * 65, flush=True)
    print(f"  Web Dashboard : http://{host}:{port}", flush=True)
    print(f"  REST API Feed : http://{host}:{port}/api/resources", flush=True)
    print(f"  Summary KPIs  : http://{host}:{port}/api/summary", flush=True)
    print("=" * 65, flush=True)
    print("  Serving frontend and REST endpoints. Press Ctrl+C to stop.\n", flush=True)

    httpd = HTTPServer((host, port), StandaloneDirectoryHandler)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer shutting down gracefully.", flush=True)
        httpd.server_close()


if __name__ == "__main__":
    port = 8000
    if len(sys.argv) > 1 and sys.argv[1].isdigit():
        port = int(sys.argv[1])
    start_server(port=port)
